package com.example;

public interface IRect extends IShape2D {
    
    ISize getSize();
    void setSize(ISize size);
}
