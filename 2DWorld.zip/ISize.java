package com.example;

public interface ISize {
    

    float getWidth();
    float getHeight();

    void setWidth(float width);
    void setHeight(float height);

    //--[ factory ]-------------------------
    // todo: implement factory
}
