package com.example;

public interface ICircle {

    public float getRadius();
    public void setRadius(float r);
}
