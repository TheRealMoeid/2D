package com.example;

public interface ISquare extends IShape2D {
    
    float getSize();
    void setSize(float size);
}
